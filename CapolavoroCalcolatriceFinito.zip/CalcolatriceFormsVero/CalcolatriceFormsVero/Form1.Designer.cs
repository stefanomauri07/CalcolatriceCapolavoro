﻿namespace CalcolatriceFormsVero
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            equalsButton = new Button();
            commaButton = new Button();
            zeroButton = new Button();
            negativeButton = new Button();
            plusButton = new Button();
            threeButton = new Button();
            twoButton = new Button();
            oneButton = new Button();
            subButton = new Button();
            sixButton = new Button();
            fiveButton = new Button();
            fourButton = new Button();
            moltButton = new Button();
            eightButton = new Button();
            sevenButton = new Button();
            divisioneButton = new Button();
            radiceButton = new Button();
            quadratoButton = new Button();
            oppositeButton = new Button();
            cancButton = new Button();
            CButton = new Button();
            CEButton = new Button();
            resultLabel = new Label();
            percButton = new Button();
            nineButton = new Button();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 4;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.Controls.Add(equalsButton, 3, 6);
            tableLayoutPanel1.Controls.Add(commaButton, 2, 6);
            tableLayoutPanel1.Controls.Add(zeroButton, 1, 6);
            tableLayoutPanel1.Controls.Add(negativeButton, 0, 6);
            tableLayoutPanel1.Controls.Add(plusButton, 3, 5);
            tableLayoutPanel1.Controls.Add(threeButton, 2, 5);
            tableLayoutPanel1.Controls.Add(twoButton, 1, 5);
            tableLayoutPanel1.Controls.Add(oneButton, 0, 5);
            tableLayoutPanel1.Controls.Add(subButton, 3, 4);
            tableLayoutPanel1.Controls.Add(sixButton, 2, 4);
            tableLayoutPanel1.Controls.Add(fiveButton, 1, 4);
            tableLayoutPanel1.Controls.Add(fourButton, 0, 4);
            tableLayoutPanel1.Controls.Add(moltButton, 3, 3);
            tableLayoutPanel1.Controls.Add(eightButton, 1, 3);
            tableLayoutPanel1.Controls.Add(sevenButton, 0, 3);
            tableLayoutPanel1.Controls.Add(divisioneButton, 3, 2);
            tableLayoutPanel1.Controls.Add(radiceButton, 2, 2);
            tableLayoutPanel1.Controls.Add(quadratoButton, 1, 2);
            tableLayoutPanel1.Controls.Add(oppositeButton, 0, 2);
            tableLayoutPanel1.Controls.Add(cancButton, 3, 1);
            tableLayoutPanel1.Controls.Add(CButton, 2, 1);
            tableLayoutPanel1.Controls.Add(CEButton, 1, 1);
            tableLayoutPanel1.Controls.Add(resultLabel, 0, 0);
            tableLayoutPanel1.Controls.Add(percButton, 0, 1);
            tableLayoutPanel1.Controls.Add(nineButton, 2, 3);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 7;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 29.9940052F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.6676674F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.6676674F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.6676674F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.6676674F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.6676674F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.6676674F));
            tableLayoutPanel1.Size = new Size(421, 510);
            tableLayoutPanel1.TabIndex = 0;
            tableLayoutPanel1.Paint += tableLayoutPanel1_Paint;
            // 
            // equalsButton
            // 
            equalsButton.BackColor = SystemColors.Highlight;
            equalsButton.Dock = DockStyle.Fill;
            equalsButton.Font = new Font("Segoe UI", 18F);
            equalsButton.ForeColor = SystemColors.ControlLightLight;
            equalsButton.Location = new Point(318, 450);
            equalsButton.Name = "equalsButton";
            equalsButton.Size = new Size(100, 57);
            equalsButton.TabIndex = 24;
            equalsButton.Text = "=";
            equalsButton.UseVisualStyleBackColor = false;
            equalsButton.Click += equalsButton_Click;
            // 
            // commaButton
            // 
            commaButton.Dock = DockStyle.Fill;
            commaButton.Font = new Font("Segoe UI", 11F);
            commaButton.Location = new Point(213, 450);
            commaButton.Name = "commaButton";
            commaButton.Size = new Size(99, 57);
            commaButton.TabIndex = 23;
            commaButton.Text = ".";
            commaButton.UseVisualStyleBackColor = true;
            commaButton.Click += commaButton_Click;
            // 
            // zeroButton
            // 
            zeroButton.Dock = DockStyle.Fill;
            zeroButton.Font = new Font("Segoe UI", 11F);
            zeroButton.Location = new Point(108, 450);
            zeroButton.Name = "zeroButton";
            zeroButton.Size = new Size(99, 57);
            zeroButton.TabIndex = 22;
            zeroButton.Text = "0";
            zeroButton.UseVisualStyleBackColor = true;
            zeroButton.Click += zeroButton_Click;
            // 
            // negativeButton
            // 
            negativeButton.Dock = DockStyle.Fill;
            negativeButton.Font = new Font("Segoe UI", 11F);
            negativeButton.Location = new Point(3, 450);
            negativeButton.Name = "negativeButton";
            negativeButton.Size = new Size(99, 57);
            negativeButton.TabIndex = 21;
            negativeButton.Text = "+/-";
            negativeButton.UseVisualStyleBackColor = true;
            negativeButton.Click += negativeButton_Click;
            // 
            // plusButton
            // 
            plusButton.Dock = DockStyle.Fill;
            plusButton.Font = new Font("Segoe UI", 18F);
            plusButton.Location = new Point(318, 391);
            plusButton.Name = "plusButton";
            plusButton.Size = new Size(100, 53);
            plusButton.TabIndex = 20;
            plusButton.Text = "+";
            plusButton.UseVisualStyleBackColor = true;
            plusButton.Click += plusButton_Click;
            // 
            // threeButton
            // 
            threeButton.Dock = DockStyle.Fill;
            threeButton.Font = new Font("Segoe UI", 11F);
            threeButton.Location = new Point(213, 391);
            threeButton.Name = "threeButton";
            threeButton.Size = new Size(99, 53);
            threeButton.TabIndex = 19;
            threeButton.Text = "3";
            threeButton.UseVisualStyleBackColor = true;
            threeButton.Click += threeButton_Click;
            // 
            // twoButton
            // 
            twoButton.Dock = DockStyle.Fill;
            twoButton.Font = new Font("Segoe UI", 11F);
            twoButton.Location = new Point(108, 391);
            twoButton.Name = "twoButton";
            twoButton.Size = new Size(99, 53);
            twoButton.TabIndex = 18;
            twoButton.Text = "2";
            twoButton.UseVisualStyleBackColor = true;
            twoButton.Click += twoButton_Click;
            // 
            // oneButton
            // 
            oneButton.Dock = DockStyle.Fill;
            oneButton.Font = new Font("Segoe UI", 11F);
            oneButton.Location = new Point(3, 391);
            oneButton.Name = "oneButton";
            oneButton.Size = new Size(99, 53);
            oneButton.TabIndex = 17;
            oneButton.Text = "1";
            oneButton.UseVisualStyleBackColor = true;
            oneButton.Click += oneButton_Click;
            // 
            // subButton
            // 
            subButton.Dock = DockStyle.Fill;
            subButton.Font = new Font("Segoe UI", 20F);
            subButton.Location = new Point(318, 332);
            subButton.Name = "subButton";
            subButton.Size = new Size(100, 53);
            subButton.TabIndex = 16;
            subButton.Text = "-";
            subButton.UseVisualStyleBackColor = true;
            subButton.Click += subButton_Click;
            // 
            // sixButton
            // 
            sixButton.Dock = DockStyle.Fill;
            sixButton.Font = new Font("Segoe UI", 11F);
            sixButton.Location = new Point(213, 332);
            sixButton.Name = "sixButton";
            sixButton.Size = new Size(99, 53);
            sixButton.TabIndex = 15;
            sixButton.Text = "6";
            sixButton.UseVisualStyleBackColor = true;
            sixButton.Click += sixButton_Click;
            // 
            // fiveButton
            // 
            fiveButton.Dock = DockStyle.Fill;
            fiveButton.Font = new Font("Segoe UI", 11F);
            fiveButton.Location = new Point(108, 332);
            fiveButton.Name = "fiveButton";
            fiveButton.Size = new Size(99, 53);
            fiveButton.TabIndex = 14;
            fiveButton.Text = "5";
            fiveButton.UseVisualStyleBackColor = true;
            fiveButton.Click += fiveButton_Click;
            // 
            // fourButton
            // 
            fourButton.Dock = DockStyle.Fill;
            fourButton.Font = new Font("Segoe UI", 11F);
            fourButton.Location = new Point(3, 332);
            fourButton.Name = "fourButton";
            fourButton.Size = new Size(99, 53);
            fourButton.TabIndex = 13;
            fourButton.Text = "4";
            fourButton.UseVisualStyleBackColor = true;
            fourButton.Click += fourButton_Click;
            // 
            // moltButton
            // 
            moltButton.Dock = DockStyle.Fill;
            moltButton.Font = new Font("Segoe UI", 18F);
            moltButton.Location = new Point(318, 273);
            moltButton.Name = "moltButton";
            moltButton.Size = new Size(100, 53);
            moltButton.TabIndex = 12;
            moltButton.Text = "×";
            moltButton.UseVisualStyleBackColor = true;
            moltButton.Click += moltButton_Click;
            // 
            // eightButton
            // 
            eightButton.Dock = DockStyle.Fill;
            eightButton.Font = new Font("Segoe UI", 11F);
            eightButton.Location = new Point(108, 273);
            eightButton.Name = "eightButton";
            eightButton.Size = new Size(99, 53);
            eightButton.TabIndex = 10;
            eightButton.Text = "8";
            eightButton.UseVisualStyleBackColor = true;
            eightButton.Click += eightButton_Click;
            // 
            // sevenButton
            // 
            sevenButton.Dock = DockStyle.Fill;
            sevenButton.Font = new Font("Segoe UI", 11F);
            sevenButton.Location = new Point(3, 273);
            sevenButton.Name = "sevenButton";
            sevenButton.Size = new Size(99, 53);
            sevenButton.TabIndex = 9;
            sevenButton.Text = "7";
            sevenButton.UseVisualStyleBackColor = true;
            sevenButton.Click += sevenButton_Click;
            sevenButton.KeyDown += sevenButton_KeyDown;
            sevenButton.KeyPress += sevenButton_KeyPress;
            // 
            // divisioneButton
            // 
            divisioneButton.Dock = DockStyle.Fill;
            divisioneButton.Font = new Font("Segoe UI", 18F);
            divisioneButton.Location = new Point(318, 214);
            divisioneButton.Name = "divisioneButton";
            divisioneButton.Size = new Size(100, 53);
            divisioneButton.TabIndex = 8;
            divisioneButton.Text = "÷";
            divisioneButton.UseVisualStyleBackColor = true;
            divisioneButton.Click += button8_Click;
            // 
            // radiceButton
            // 
            radiceButton.Dock = DockStyle.Fill;
            radiceButton.Font = new Font("Segoe UI", 11F);
            radiceButton.Location = new Point(213, 214);
            radiceButton.Name = "radiceButton";
            radiceButton.Size = new Size(99, 53);
            radiceButton.TabIndex = 7;
            radiceButton.Text = "²√x";
            radiceButton.UseVisualStyleBackColor = true;
            radiceButton.Click += radiceButton_Click;
            // 
            // quadratoButton
            // 
            quadratoButton.Dock = DockStyle.Fill;
            quadratoButton.Font = new Font("Segoe UI", 11F);
            quadratoButton.Location = new Point(108, 214);
            quadratoButton.Name = "quadratoButton";
            quadratoButton.Size = new Size(99, 53);
            quadratoButton.TabIndex = 6;
            quadratoButton.Text = "x²";
            quadratoButton.UseVisualStyleBackColor = true;
            quadratoButton.Click += quadratoButton_Click;
            // 
            // oppositeButton
            // 
            oppositeButton.Dock = DockStyle.Fill;
            oppositeButton.Font = new Font("Segoe UI", 11F);
            oppositeButton.Location = new Point(3, 214);
            oppositeButton.Name = "oppositeButton";
            oppositeButton.Size = new Size(99, 53);
            oppositeButton.TabIndex = 5;
            oppositeButton.Text = "1/x";
            oppositeButton.UseVisualStyleBackColor = true;
            oppositeButton.Click += oppositeButton_Click;
            // 
            // cancButton
            // 
            cancButton.Dock = DockStyle.Fill;
            cancButton.Font = new Font("Segoe UI", 11F);
            cancButton.Location = new Point(318, 155);
            cancButton.Name = "cancButton";
            cancButton.Size = new Size(100, 53);
            cancButton.TabIndex = 4;
            cancButton.Text = "CANC";
            cancButton.UseVisualStyleBackColor = true;
            cancButton.Click += cancButton_Click;
            // 
            // CButton
            // 
            CButton.Dock = DockStyle.Fill;
            CButton.Font = new Font("Segoe UI", 11F);
            CButton.Location = new Point(213, 155);
            CButton.Name = "CButton";
            CButton.Size = new Size(99, 53);
            CButton.TabIndex = 3;
            CButton.Text = "C";
            CButton.UseVisualStyleBackColor = true;
            CButton.Click += CButton_Click;
            // 
            // CEButton
            // 
            CEButton.Dock = DockStyle.Fill;
            CEButton.Font = new Font("Segoe UI", 11F);
            CEButton.Location = new Point(108, 155);
            CEButton.Name = "CEButton";
            CEButton.Size = new Size(99, 53);
            CEButton.TabIndex = 2;
            CEButton.Text = "CE";
            CEButton.UseVisualStyleBackColor = true;
            CEButton.Click += CEButton_Click;
            // 
            // resultLabel
            // 
            resultLabel.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(resultLabel, 4);
            resultLabel.Dock = DockStyle.Fill;
            resultLabel.Font = new Font("Segoe UI", 25F);
            resultLabel.Location = new Point(3, 0);
            resultLabel.Name = "resultLabel";
            resultLabel.Size = new Size(415, 152);
            resultLabel.TabIndex = 0;
            resultLabel.TextAlign = ContentAlignment.MiddleRight;
            resultLabel.Click += label1_Click;
            // 
            // percButton
            // 
            percButton.Dock = DockStyle.Fill;
            percButton.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            percButton.Location = new Point(3, 155);
            percButton.Name = "percButton";
            percButton.Size = new Size(99, 53);
            percButton.TabIndex = 1;
            percButton.Text = "%";
            percButton.UseVisualStyleBackColor = true;
            percButton.Click += button1_Click;
            // 
            // nineButton
            // 
            nineButton.Dock = DockStyle.Fill;
            nineButton.Font = new Font("Segoe UI", 11F);
            nineButton.Location = new Point(213, 273);
            nineButton.Name = "nineButton";
            nineButton.Size = new Size(99, 53);
            nineButton.TabIndex = 11;
            nineButton.Text = "9";
            nineButton.UseVisualStyleBackColor = true;
            nineButton.Click += nineButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(421, 510);
            Controls.Add(tableLayoutPanel1);
            KeyPreview = true;
            Name = "Form1";
            Text = "Calcolatrice";
            KeyDown += Form1_KeyDown;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Label resultLabel;
        private Button radiceButton;
        private Button quadratoButton;
        private Button oppositeButton;
        private Button cancButton;
        private Button CButton;
        private Button CEButton;
        private Button percButton;
        private Button eightButton;
        private Button sevenButton;
        private Button divisioneButton;
        private Button nineButton;
        private Button equalsButton;
        private Button commaButton;
        private Button zeroButton;
        private Button negativeButton;
        private Button plusButton;
        private Button threeButton;
        private Button twoButton;
        private Button oneButton;
        private Button subButton;
        private Button sixButton;
        private Button fiveButton;
        private Button fourButton;
        private Button moltButton;
    }
}
