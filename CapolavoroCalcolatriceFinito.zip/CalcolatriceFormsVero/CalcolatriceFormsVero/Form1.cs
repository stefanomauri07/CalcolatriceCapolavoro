

using System.Windows.Forms;
using System.Xml.XPath;

namespace CalcolatriceFormsVero
{
    public partial class Form1 : Form
    {
        static double primoOperatore;
        static double secondoOperatore;
        static char operazione;
        static string[] vettore;
        static double? risultato;
        static bool contaOp = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)  //percentuale
        {
            try
            {
                if (!contaOp)
                {
                    resultLabel.Text = "0";
                }
                else
                {
                    vettore = resultLabel.Text.Split(operazione);
                    char[] vett2 = resultLabel.Text.ToCharArray(0, 3);
                    for (int i = 0; i < vett2.Length; i++)
                    {
                        if (vett2[i] == '+' || vett2[i] == '-' || vett2[i] == '*' || vett2[i] == '/')
                        {
                            if (vett2[i] == '+' || vett2[i] == '-')
                            {
                                resultLabel.Text = vettore[0] + operazione + ((double.Parse(vettore[1]) * double.Parse(vettore[0])) / 100);
                            }
                            else
                            {
                                resultLabel.Text = vettore[0] + operazione + (double.Parse(vettore[1]) / 100);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                resultLabel.Text = "operazione non valida";
            }
        }

        private void oppositeButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (contaOp)
                {
                    vettore = resultLabel.Text.Split(operazione);
                    if (vettore.Length == 1)
                    {
                        vettore[0] = (1 / (double.Parse(vettore[0]))).ToString();
                        resultLabel.Text = vettore[0] + operazione;
                    }
                    else
                    {
                        vettore[1] = (1 / (double.Parse(vettore[1]))).ToString();
                        resultLabel.Text = vettore[0] + operazione + vettore[1];
                    }
                }
                else
                {
                    resultLabel.Text = (1 / (double.Parse(resultLabel.Text))).ToString();
                }
            }
            catch (Exception ex)
            {
                resultLabel.Text = "operazione non valida";
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            try
            {
                if (resultLabel.Text == "operazione non valida")
                {
                    resultLabel.Text = null;
                }
                if (contaOp)
                {
                    equalsButton_Click(sender, e);
                }
                operazione = '/';
                resultLabel.Text = resultLabel.Text + "/";
                contaOp = true;
            }
            catch (Exception ex)
            {
                resultLabel.Text = "operazione non valida";
            }
        }

        private void oneButton_Click(object sender, EventArgs e)
        {
            if (resultLabel.Text == "operazione non valida")
            {
                resultLabel.Text = null;
            }
            resultLabel.Text = resultLabel.Text + "1";
        }

        private void zeroButton_Click(object sender, EventArgs e)
        {
            if (resultLabel.Text == "operazione non valida")
            {
                resultLabel.Text = null;
            }
            resultLabel.Text = resultLabel.Text + "0";
        }

        private void twoButton_Click(object sender, EventArgs e)
        {
            if (resultLabel.Text == "operazione non valida")
            {
                resultLabel.Text = null;
            }
            resultLabel.Text = resultLabel.Text + "2";
        }

        private void threeButton_Click(object sender, EventArgs e)
        {
            if (resultLabel.Text == "operazione non valida")
            {
                resultLabel.Text = null;
            }
            resultLabel.Text = resultLabel.Text + "3";
        }

        private void fourButton_Click(object sender, EventArgs e)
        {
            if (resultLabel.Text == "operazione non valida")
            {
                resultLabel.Text = null;
            }
            resultLabel.Text = resultLabel.Text + "4";
        }

        private void fiveButton_Click(object sender, EventArgs e)
        {
            if (resultLabel.Text == "operazione non valida")
            {
                resultLabel.Text = null;
            }
            resultLabel.Text = resultLabel.Text + "5";
        }

        private void sixButton_Click(object sender, EventArgs e)
        {
            if (resultLabel.Text == "operazione non valida")
            {
                resultLabel.Text = null;
            }
            resultLabel.Text = resultLabel.Text + "6";
        }

        private void sevenButton_Click(object sender, EventArgs e)
        {
            if (resultLabel.Text == "operazione non valida")
            {
                resultLabel.Text = null;
            }
            resultLabel.Text = resultLabel.Text + "7";
        }

        private void eightButton_Click(object sender, EventArgs e)
        {
            if (resultLabel.Text == "operazione non valida")
            {
                resultLabel.Text = null;
            }
            resultLabel.Text = resultLabel.Text + "8";
        }

        private void nineButton_Click(object sender, EventArgs e)
        {
            if (resultLabel.Text == "operazione non valida")
            {
                resultLabel.Text = null;
            }
            resultLabel.Text = resultLabel.Text + "9";
        }

        public void plusButton_Click(object sender, EventArgs e)
        {
            if (resultLabel.Text == "operazione non valida")
            {
                resultLabel.Text = null;
            }
            try
            {
                if (contaOp)
                {
                    equalsButton_Click(sender, e);
                }
                operazione = '+';
                resultLabel.Text = resultLabel.Text + "+";
                contaOp = true;
            }
            catch (Exception ex)
            {
                resultLabel.Text = "operazione non valida";
            }
        }

        private void equalsButton_Click(object sender, EventArgs e)
        {
            try
            {
                vettore = resultLabel.Text.Split(operazione);

                if (vettore.Length == 1)
                {
                    Console.WriteLine("operazione non valida");
                }
                else
                {

                    primoOperatore = double.Parse(vettore[0]);
                    secondoOperatore = double.Parse((vettore[1]));
                    if (operazione == '+')
                    {
                        risultato = primoOperatore + secondoOperatore;
                        resultLabel.Text = risultato.ToString();
                    }
                    else if (operazione == '-')
                    {
                        risultato = primoOperatore - secondoOperatore;
                        resultLabel.Text = risultato.ToString();
                    }
                    else if (operazione == '/')
                    {
                        risultato = primoOperatore / secondoOperatore;
                        resultLabel.Text = risultato.ToString();
                    }
                    else if (operazione == '*')
                    {
                        risultato = primoOperatore * secondoOperatore;
                        resultLabel.Text = risultato.ToString();
                    }
                    contaOp = false;
                }
            }
            catch (Exception)
            {
                resultLabel.Text = "operazione non valida";
            }
        }

        private void subButton_Click(object sender, EventArgs e)
        {
            if (resultLabel.Text == "operazione non valida")
            {
                resultLabel.Text = null;
            }
            try
            {
                if (contaOp)
                {
                    equalsButton_Click(sender, e);
                }
                operazione = '-';
                resultLabel.Text = resultLabel.Text + "-";
                contaOp = true;
            }
            catch (Exception)
            {
                resultLabel.Text = "operazione non valida";
            }

        }

        private void moltButton_Click(object sender, EventArgs e)
        {
            if (resultLabel.Text == "operazione non valida")
            {
                resultLabel.Text = null;
            }
            try
            {
                if (contaOp)
                {
                    equalsButton_Click(sender, e);
                }
                operazione = '*';
                resultLabel.Text = resultLabel.Text + "*";
                contaOp = true;
            }
            catch (Exception ex)
            {
                resultLabel.Text = "operazione non valida";
            }
        }

        private void CButton_Click(object sender, EventArgs e)
        {
            try
            {
                resultLabel.Text = null;
                contaOp = false;
            }
            catch (Exception ex)
            {
                resultLabel.Text = "operazione non valida";
            }
        }

        private void CEButton_Click(object sender, EventArgs e)
        {
            try
            {
                vettore = resultLabel.Text.Split('/', '*', '+', '-');
                if (resultLabel.Text.Contains('/') || resultLabel.Text.Contains('*') || resultLabel.Text.Contains('+') || resultLabel.Text.Contains('-'))
                {
                    CButton_Click(sender, e);
                }
                if (vettore.Length == 1)
                {
                    CButton_Click(sender, e);
                }

                else if (vettore.Length == 2)
                {
                    resultLabel.Text = vettore[0] + operazione;
                }
            }
            catch (Exception ex)
            {
                resultLabel.Text = "operazione non valida";
            }

        }

        private void cancButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (resultLabel.Text == "operazione non valida")
                {
                    resultLabel.Text = null;
                }
                if (resultLabel.Text.Length <= 1)
                {
                    resultLabel.Text = null;
                }
                else
                {

                    int pos = resultLabel.Text.Length - 1;

                    if (resultLabel.Text[pos] == operazione)
                    {
                        contaOp = false;
                    }

                    resultLabel.Text = resultLabel.Text.Remove(pos, 1);
                }
            }
            catch (Exception ex)
            {
                resultLabel.Text = "operazione non valida";
            }
        }

        private void radiceButton_Click(object sender, EventArgs e)
        {

            try
            {
                if (contaOp)
                {
                    vettore = resultLabel.Text.Split(operazione);
                    if (vettore.Length == 1)
                    {
                        if (double.Parse(vettore[0]) < 0)
                        {
                            resultLabel.Text = "radice minore di 0 impossibile";
                        }
                        else
                        {
                            resultLabel.Text = Math.Sqrt(double.Parse(resultLabel.Text)).ToString();
                        }


                    }
                    else
                    {
                        if (double.Parse(vettore[1]) < 0)
                        {
                            resultLabel.Text = "radice minore di 0 impossibile";
                        }
                        else
                        {
                            primoOperatore = double.Parse(vettore[1]);
                            primoOperatore = Math.Sqrt(primoOperatore);
                            resultLabel.Text = vettore[0] + operazione + primoOperatore;
                        }

                    }
                }
                else
                {
                    if (double.Parse(resultLabel.Text) < 0)
                    {
                        resultLabel.Text = "operazione non valida";
                    }
                    else
                    {
                        resultLabel.Text = Math.Sqrt(double.Parse(resultLabel.Text)).ToString();
                    }

                }
            }
            catch (Exception ex)
            {
                resultLabel.Text = "operazione non valida";
            }
        }


        private void quadratoButton_Click(object sender, EventArgs e)
        {

            try
            {
                if (contaOp)
                {
                    vettore = resultLabel.Text.Split(operazione);
                    if (vettore.Length == 1)
                    {
                        resultLabel.Text = Math.Pow(double.Parse(resultLabel.Text), 2).ToString();

                    }
                    else
                    {
                        primoOperatore = double.Parse(vettore[1]);
                        primoOperatore = Math.Pow(primoOperatore, 2);
                        resultLabel.Text = vettore[0] + operazione + primoOperatore;
                    }
                }
                else
                {
                    resultLabel.Text = Math.Pow(double.Parse(resultLabel.Text), 2).ToString();
                }
            }
            catch (Exception ex)
            {
                resultLabel.Text = "operazione non valida";
            }
        }

        private void negativeButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (!contaOp)
                {
                    resultLabel.Text = (double.Parse(resultLabel.Text) * -1).ToString();
                }
                else
                {
                    vettore = resultLabel.Text.Split(operazione);
                    resultLabel.Text = vettore[0] + operazione + double.Parse(vettore[1]) * -1;
                    contaOp = false;
                }
            }
            catch (Exception ecc)
            {
                resultLabel.Text = "operazione non valida";
            }
        }

        private void commaButton_Click(object sender, EventArgs e)
        {
            resultLabel.Text += ',';
        }

        private void sevenButton_KeyDown(object sender, KeyEventArgs e)
        {



        }

        private void sevenButton_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            //0
            if (e.KeyCode == Keys.NumPad0)
            {
                zeroButton.PerformClick();
            }
            //1
            if (e.KeyCode == Keys.NumPad1)
            {
                oneButton.PerformClick();
            }
            //2
            if (e.KeyCode == Keys.NumPad2)
            {
                twoButton.PerformClick();
            }
            //3
            if (e.KeyCode == Keys.NumPad3)
            {
                threeButton.PerformClick();
            }
            //4
            if (e.KeyCode == Keys.NumPad4)
            {
                fourButton.PerformClick();
            }
            //5
            if (e.KeyCode == Keys.NumPad5)
            {
                fiveButton.PerformClick();
            }
            //6
            if (e.KeyCode == Keys.NumPad6)
            {
                sixButton.PerformClick();
            }
            //7
            if (e.KeyCode == Keys.NumPad7)
            {
                sevenButton.PerformClick();
            }
            //8
            if (e.KeyCode == Keys.NumPad8)
            {
                eightButton.PerformClick();
            }
            //9
            if (e.KeyCode == Keys.NumPad9)
            {
                nineButton.PerformClick();
            }
            
            // molt
            if (e.KeyCode == Keys.Multiply)
            {
                moltButton.PerformClick();
            }
            // divisione
            if (e.KeyCode == Keys.Divide)
            {
                divisioneButton.PerformClick();
            }
            // add
            if (e.KeyCode == Keys.Add)
            {
                plusButton.PerformClick();
            }
            //sub
            if (e.KeyCode == Keys.Subtract)
            {
                subButton.PerformClick();
            }
            //canc
            if (e.KeyCode == Keys.Back)
            {
                cancButton.PerformClick();
            }
            //dot
            if (e.KeyCode == Keys.Oemcomma)
            {
                commaButton.PerformClick();
            }
            //enter
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                equalsButton.PerformClick();
            }

        }
    }
}